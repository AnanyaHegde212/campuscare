package com.campuscare.controller;

import com.campuscare.model.Grievance;
import com.campuscare.service.GrievanceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GrievanceController {

    private final GrievanceService grievanceService;

    public GrievanceController(GrievanceService grievanceService) {
        this.grievanceService = grievanceService;
    }

    @GetMapping("/grievance")
    public String showGrievanceForm(Model model) {

        model.addAttribute("grievance", new Grievance());

        return "grievance";
    }

    @PostMapping("/grievance")
    public String submitGrievance(Grievance grievance) {

        grievanceService.saveGrievance(grievance);

        return "redirect:/success?id=" + grievance.getId();
    }

    @GetMapping("/track-grievance")
    public String trackGrievance(
            @RequestParam(required = false) Long id,
            Model model) {

        if (id != null) {

            Grievance grievance =
                    grievanceService.getGrievanceById(id);

            if (grievance != null) {

                model.addAttribute(
                        "grievance",
                        grievance
                );

            } else {

                model.addAttribute(
                        "error",
                        "No grievance found with ID #" + id
                );

            }
        }

        return "track-grievance";
    }
}