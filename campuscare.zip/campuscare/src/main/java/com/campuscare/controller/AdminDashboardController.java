package com.campuscare.controller;

import com.campuscare.model.Grievance;
import com.campuscare.service.GrievanceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class AdminDashboardController {

    private final GrievanceService grievanceService;

    public AdminDashboardController(GrievanceService grievanceService) {
        this.grievanceService = grievanceService;
    }

    @GetMapping("/admin/dashboard")
    public String dashboard(Model model) {

        List<Grievance> grievances = grievanceService.getAllGrievances();

        long total = grievances.size();

        long pending = grievances.stream()
                .filter(g -> "Pending".equalsIgnoreCase(g.getStatus()))
                .count();

        long inProgress = grievances.stream()
                .filter(g -> "In Progress".equalsIgnoreCase(g.getStatus()))
                .count();

        long resolved = grievances.stream()
                .filter(g -> "Resolved".equalsIgnoreCase(g.getStatus()))
                .count();

        model.addAttribute("total", total);
        model.addAttribute("pending", pending);
        model.addAttribute("inProgress", inProgress);
        model.addAttribute("resolved", resolved);

        return "admin-dashboard";
    }
}