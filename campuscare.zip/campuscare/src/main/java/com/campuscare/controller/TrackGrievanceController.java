package com.campuscare.controller;

import com.campuscare.model.Grievance;
import com.campuscare.service.GrievanceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TrackGrievanceController {

    private final GrievanceService grievanceService;

    public TrackGrievanceController(GrievanceService grievanceService) {
        this.grievanceService = grievanceService;
    }

    @GetMapping("/track-grievance")
    public String trackPage() {
        return "track-grievance";
    }

    @PostMapping("/track-grievance")
    public String trackGrievance(
            @RequestParam Long id,
            Model model) {

        Grievance grievance = grievanceService.getGrievanceById(id);

        if (grievance != null) {
            model.addAttribute("grievance", grievance);
        } else {
            model.addAttribute("error", "Grievance not found. Please check the ID.");
        }

        return "track-grievance";
    }
}
