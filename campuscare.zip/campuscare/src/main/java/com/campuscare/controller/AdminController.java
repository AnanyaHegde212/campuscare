package com.campuscare.controller;

import com.campuscare.model.Grievance;
import com.campuscare.service.GrievanceService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class AdminController {

    private final GrievanceService grievanceService;

    public AdminController(GrievanceService grievanceService) {
        this.grievanceService = grievanceService;
    }

    @GetMapping("/admin/grievances")
    public String viewGrievances(Model model) {

        List<Grievance> grievances = grievanceService.getAllGrievances();

        model.addAttribute("grievances", grievances);

        return "admin-grievances";
    }

    @PostMapping("/admin/update-status")
    public String updateStatus(
            @RequestParam Long id,
            @RequestParam String status) {

        grievanceService.updateStatus(id, status);

        return "redirect:/admin/grievances";
    }
}