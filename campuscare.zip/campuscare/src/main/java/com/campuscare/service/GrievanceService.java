package com.campuscare.service;

import com.campuscare.model.Grievance;
import com.campuscare.repository.GrievanceRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GrievanceService {

    private final GrievanceRepository grievanceRepository;

    public GrievanceService(GrievanceRepository grievanceRepository) {
        this.grievanceRepository = grievanceRepository;
    }

    public Grievance saveGrievance(Grievance grievance) {

        if (grievance.getStatus() == null || grievance.getStatus().isEmpty()) {
            grievance.setStatus("Pending");
        }

        return grievanceRepository.save(grievance);
    }

    public List<Grievance> getAllGrievances() {
        return grievanceRepository.findAll();
    }

    public Grievance getGrievanceById(Long id) {
        return grievanceRepository.findById(id).orElse(null);
    }

    public void updateStatus(Long id, String status) {

        Grievance grievance = grievanceRepository.findById(id).orElse(null);

        if (grievance != null) {
            grievance.setStatus(status);
            grievanceRepository.save(grievance);
        }
    }
}